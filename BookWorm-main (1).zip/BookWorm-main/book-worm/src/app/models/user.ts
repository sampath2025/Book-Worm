export class User {
    userId: number;
    firstName: string;
    lastName: number;
    username: string;
    userTypeId: number;
    isLoggedIn: boolean;
}
